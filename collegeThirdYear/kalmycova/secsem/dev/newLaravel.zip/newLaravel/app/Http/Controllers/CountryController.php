<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;


    public function index(){
        return Country::all();
    }

    public function getOne($id){
        return Country::findOrFail($id);
    }

    public function add(Request $request){
        return Country::create(['name' => $request->input('name')]);
    }

    public function delete($id){
        $countryToChange =  Country::findOrFail($id);
        $countryToChange->delete();
    }

    public function change($id, Request $request){
        $countryToChange =  Country::findOrFail($id);
        $countryToChange->update(['name'=>$request->input('name')]);
        return $countryToChange;
    }




}
