<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Education_Hub
 */

?>

<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title">Ничего не найдено</h1>
	</header><!-- .page-header -->

	<div class="page-content">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( wp_kses( __( 'Готовы опубликовать свою первую запись? <a href="%1$s">Начните здесь</a>.', 'education-hub' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

		<?php elseif ( is_search() ) : ?>

			<p>Извините, ничего не найдено по условиям поиска. Попробуйте еще раз, используя другие ключевые слова.</p>
			<?php get_search_form(); ?>

		<?php else : ?>

			<p>Кажется, мы не можем найти то, что Вы ищете. Попробуйте воспользоваться поиском по сайту.</p>
			<?php get_search_form(); ?>

		<?php endif; ?>
	</div><!-- .page-content -->
</section><!-- .no-results -->
